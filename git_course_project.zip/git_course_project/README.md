this is my project demonstrating a gitflow workflow
for Atlassian's Version Control with Git course on Coursera
